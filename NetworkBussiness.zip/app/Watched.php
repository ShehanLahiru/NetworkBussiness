<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Watched extends Model
{
    // public function user(){

    //     return $this->hasMany('App\User','user_id','id');
    // }
    // public function order(){

    //     return $this->hasMany('App\Order','user_id','id');
    // }
}
