<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayBill extends Model
{
    //
}
