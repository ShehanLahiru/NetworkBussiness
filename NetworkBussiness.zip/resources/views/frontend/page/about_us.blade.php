@include('frontend.layouts.head')
<div class="site-section" style="background-image: url(images/main11.jpeg);background-size: cover;
    background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-12 col-lg-12 mb-12">
            <div class="post-entry-main" style="background: rgba(0,0,0,.4)">
                <div class="text p-4">
                    < class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">  <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>

                </div>
            </div>
        </div>
    </div>
</div>
@include('frontend.layouts.footer')
