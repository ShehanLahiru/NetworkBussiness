<?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="slide-one-item home-slider owl-carousel">
    <div class="site-blocks-cover overlay" style="background-image: url(images/main6.jpg);" data-aos="fade"
        data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row align-items-center text-center image-details">
                <div class="col-md-6">
                    <h1 class="head-topic">Welcome</h1>
                    <h2 class="sub-topic">Remote Promotions Sri Lanka</h2>
                </div>
                <div class="col-lg-10 col-md-12">
                    <p class="page-para">
                        ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="site-blocks-cover overlay" style="background-image: url(images/main7.jpg);" data-aos="fade"
        data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row align-items-center text-center image-details">
                <div class="col-md-6">
                    <h1 class="head-topic">Welcome</h1>
                    <h2 class="sub-topic">Remote Promotions Sri Lanka</h2>
                </div>
                <div class="col-lg-10 col-md-12">
                    <p class="page-para">
                        ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="site-blocks-cover overlay" style="background-image: url(images/main1.jpg);" data-aos="fade"
        data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row align-items-center text-center image-details">
                <div class="col-md-6">
                    <h1 class="head-topic">Welcome</h1>
                    <h2 class="sub-topic">Remote Promotions Sri Lanka</h2>
                </div>
                <div class="col-lg-10 col-md-12">
                    <p class="page-para">
                        ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="site-section">
    <div class="container">
        <div class="row no-gutters align-items-stretch h-100">
            <div class="col-md-6 col-lg-6 mb-6">
                <div class="post-entry">
                    <div class="image">
                        <a href="<?php echo e(route('videoes')); ?>"><img src=<?php echo e(asset("images/youtube.jpg")); ?> alt="Image" class="img-fluid" style="height: 200px"></a>
                    </div>
                    <div class="text p-4">
                        <a href="<?php echo e(route('videoes')); ?>">  <h2 class="h2 text-main">Watch videos</h2></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 mb-6">
                <div class="post-entry">
                    <div class="image">
                        <a href="<?php echo e(route('marketing')); ?>"> <img src=<?php echo e(asset("images/marketing1.jpg")); ?> alt="Image" class="img-fluid"
                            style="height: 200px"></a>
                    </div>
                    <div class="text p-4">
                        <a href="<?php echo e(route('marketing')); ?>">  <h2 class="h2 text-main">Marketing</h2></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 mb-6">
                <div class="post-entry">
                    <div class="image">
                        <a href="<?php echo e(route('productCategories')); ?>">  <img src=<?php echo e(asset("images/products3.jpg")); ?> alt="Image" class="img-fluid"
                            style="height: 200px"></a>
                    </div>
                    <div class="text p-4">
                        <a href="<?php echo e(route('productCategories')); ?>"> <h2 class="h2 text-main">Products</h2></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 mb-6">
                <div class="post-entry">
                    <div class="image">
                        <a href="<?php echo e(route('billing')); ?>"> <img src=<?php echo e(asset("images/billing1.jpg")); ?> alt="Image" class="img-fluid" style="height: 200px"></a>
                    </div>
                    <div class="text p-4">
                        <a href="<?php echo e(route('billing')); ?>"> <h2 class="h2 text-main">Bill Payments</h2></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="site-section" style="background-image: url(images/main12.jpg); margin-top:1px;background-size: cover;
    background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-12 col-lg-12 mb-12">
            <div class="post-entry-main" style="background: rgba(0,0,0,.4)">
                <div class="text p-4">
                    <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">ඉතා පහසුවෙන් අන්තර්ජාලයෙන් මුදල් ඉපැයීමට අප හා එකතුවෙන්න..
                    </h2><br>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="site-section">
    <div class="container">
        <div class="row no-gutters align-items-stretch h-100">
            <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                    <div class="image">
                        <img src=<?php echo e(asset($productCategory->image_url)); ?> alt="Image" class="img-fluid" style="height: 200px">
                    </div>
                    <div class="text p-4">
                        <h2 class="h2 text-main"> <a href="<?php echo e(route('products', $productCategory->id)); ?>"><?php echo e($productCategory->name); ?></a></h2>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>

<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>









<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/frontend/page/home.blade.php ENDPATH**/ ?>