<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="pull-right">
                    <a href="<?php echo e(route('product.index')); ?>">
                        <button class="btn btn-dark" style="margin-right: 15px;">Back</button>
                    </a>
                </div>
                <div class="card-header">
                    <h4 class="card-title"> Create Product</h4>
                </div>
                <div class="card-body">
                    <form id="riddle_create" method="post" action="<?php echo e(route('product.store')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__("Name")); ?></label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="description"><?php echo e(__("Link")); ?></label>
                                    <textarea type="text" rows="20" name="link" class="form-control"
                                        style="border:1px solid #E3E3E3" required><?php echo e(old('link')); ?></textarea>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'link'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="category"><?php echo e(__("Category")); ?></label>
                                    <select name="category" class="form-control"  style="border:1px solid #E3E3E3"required>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=<?php echo e($category->id); ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label class="d-block" for="title"><?php echo e(__(" Image")); ?></label>
                                    <img class="gal-img prev_img" id="prev_img" src="<?php echo e(asset('assets/img/dummy.jpg')); ?>">
                                    <input type="file" class="custom-file-input" name="image" id="custom-file-input" required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'image'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card-footer ">
                            <button type="submit"
                                class="btn btn-primary float-right btn-round"><?php echo e(__('Create')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', [
'namePage' => 'products',
'class' => 'sidebar-mini',
'activePage' => 'products',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/products/create.blade.php ENDPATH**/ ?>