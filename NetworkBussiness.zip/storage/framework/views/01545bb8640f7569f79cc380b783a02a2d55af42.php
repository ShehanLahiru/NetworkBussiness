<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="pull-right">
                    <a href="<?php echo e(route('account.index')); ?>">
                        <button class="btn btn-dark" style="margin-right: 15px;">Back</button>
                    </a>
                </div>
                <div class="card-header">
                    <h4 class="card-title"> Add Balance</h4>
                </div>
                <div class="card-body">
                    <form id="riddle_create" method="post" action="<?php echo e(route('account.store')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="id"><?php echo e(__("ID")); ?></label>
                                    <input type="text" name="id" class="form-control" value="<?php echo e(old('id')); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="amount"><?php echo e(__("Amount")); ?></label>
                                    <select name="amount" class="form-control"  style="border:1px solid #E3E3E3" required>
                                        <option value= 1500.00 >1500</option>
                                    </select>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label class="d-block" for="title"><?php echo e(__(" Voucher")); ?></label>
                                    <img class="gal-img prev_img" id="prev_img" src="<?php echo e(asset('assets/img/dummy.jpg')); ?>">
                                    <input type="file" class="custom-file-input" name="image" id="custom-file-input">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'image'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer ">
                            <button type="submit"
                                class="btn btn-primary float-right btn-round"><?php echo e(__('Add')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', [
'namePage' => 'projects',
'class' => 'sidebar-mini',
'activePage' => 'projects',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/marketings/create.blade.php ENDPATH**/ ?>