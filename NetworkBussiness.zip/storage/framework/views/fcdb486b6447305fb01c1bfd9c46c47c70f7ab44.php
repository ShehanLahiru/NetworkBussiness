<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Withdraw List</h4>
                    <form id="item" method="post" action="<?php echo e(route('backend.searchByID','Withdraw')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-3">
                            <div class="form-group">
                                <label for="id"><?php echo e(__("Search by ID")); ?></label>
                                <input type="text" class="form-control" name="id">
                                </div>
                            </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Search')); ?></button>
                        </div>
                    </div>
                </form>
                    

                    <form id="item" method="post" action="<?php echo e(route('backend.searchByDate','Withdraw')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-3">
                            <div class="form-group">
                                <label for="from"><?php echo e(__(" From")); ?></label>
                                <input type="text" class="form-control" name="from" data-provide="datepicker">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-th"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="to"><?php echo e(__("To")); ?></label>
                                <input type="text" class="form-control" name="to" data-provide="datepicker">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-th"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-6">
                            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Search')); ?></button>
                        </div>
                    </div>
                </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-primary">
                                <th>ID</th>
                                <th>User ID</th>
                                <th>Name</th>
                                <th>Amount</th>
                                <th>Account_No</th>
                                <th>Status</th>
                                <th>Action</th>

                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($withdraw->id); ?></td>
                                    <td><?php echo e($withdraw->user_id); ?></td>
                                    <td><?php echo e($withdraw->name); ?></td>
                                    <td><?php echo e($withdraw->amount); ?></td>
                                    <td><?php echo e($withdraw->status); ?></td>
                                    <td><?php echo e($withdraw->acc_no); ?></td>
                                    <td>
                                        <?php if( $withdraw->status=='pending' ): ?>
                                            <form method="post" action="<?php echo e(route('withdraw.destroy',$withdraw->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger" type="submit">Delete</button>
                                            </form>
                                            <form method="post" action="<?php echo e(route('withdraw.changeStatus',$withdraw->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('post'); ?>
                                                <button class="btn btn-primary" type="submit">Confirm</button>
                                            </form>
                                            <?php endif; ?>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo e($withdraws->links()); ?>

</div>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript"
    src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
<script>
    $(".form-control").attr("autocomplete", "off");
    $(document).ready(function() {
        $('.datepicker').datepicker();
    });
</script>
<link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', [
    'namePage' => 'withdraws',
    'class' => 'sidebar-mini',
    'activePage' => 'withdraws',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/withdraws/index.blade.php ENDPATH**/ ?>