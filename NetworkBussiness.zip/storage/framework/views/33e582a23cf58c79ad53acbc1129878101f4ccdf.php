<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="pull-right">
                    <a href="<?php echo e(route('payBill.index')); ?>">
                        <button class="btn btn-dark" style="margin-right: 15px;">Back</button>
                    </a>
                </div>
                <div class="card-header">
                    <h4 class="card-title"> Pay Bills</h4>
                </div>
                <div class="card-body">
                    <form id="riddle_create" method="post" action="<?php echo e(route('payBill.store')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="id"><?php echo e(__("ID")); ?></label>
                                    <input type="text" name="id" class="form-control" value="<?php echo e(old('id')); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__("Name")); ?></label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="acc_no"><?php echo e(__("Account No")); ?></label>
                                    <input type="text" name="acc_no" class="form-control" value="<?php echo e(old('acc_no')); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'acc_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="company"><?php echo e(__("Company")); ?></label>
                                    <select name="company" class="form-control"  style="border:1px solid #E3E3E3" required>
                                        <option value="Insurance">Insurance</option>
                                        <option value="DialogTv">DialogTv</option>
                                        <option value="Sri Lanka Telecom">Sri Lanka Telecom</option>
                                        <option value="Dialog">Dialog</option>
                                        <option value="Mobitel">Mobitel</option>
                                        <option value="Etisalat">Etisalat</option>
                                        <option value="Hutch">Hutch</option>
                                    </select>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'company'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="amount"><?php echo e(__("Amount")); ?></label>
                                    <input type="text" name="amount" class="form-control" value="<?php echo e(old('amount')); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer ">
                            <button type="submit"
                                class="btn btn-primary float-right btn-round"><?php echo e(__('Pay')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', [
'namePage' => 'payBills',
'class' => 'sidebar-mini',
'activePage' => 'payBills',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/payBills/create.blade.php ENDPATH**/ ?>