<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="pull-right">
                    <a href="<?php echo e(route('backend.users.index')); ?>">
                        <button class="btn btn-dark" style="margin-right: 15px;">Back</button>
                    </a>
                </div>
                <div class="card-header">
                    <h4 class="card-title"> Create users</h4>
                </div>
                <div class="card-body">
                    <form id="riddle_create" method="post" action="<?php echo e(route('backend.users.store')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__("Name")); ?></label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="email"><?php echo e(__("Email")); ?></label>
                                    <input type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="balance"><?php echo e(__("Balance")); ?></label>
                                    <input type="text" name="balance" class="form-control" value="<?php echo e(old('balance')); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'balance'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="parent_id"><?php echo e(__("parent_id")); ?></label>
                                    <input type="text" name="parent_id" class="form-control" value="<?php echo e(old('parent_id')); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'parent_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="password"><?php echo e(__("Password")); ?></label>
                                    <input type="text" name="password" class="form-control" value="<?php echo e(old('password')); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer ">
                            <button type="submit"
                                class="btn btn-primary float-right btn-round"><?php echo e(__('Create')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', [
'namePage' => 'users',
'class' => 'sidebar-mini',
'activePage' => 'users',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/users/create.blade.php ENDPATH**/ ?>