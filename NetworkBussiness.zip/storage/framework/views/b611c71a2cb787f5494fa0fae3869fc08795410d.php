<?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="site-section">
    <div class="container">
        <div class="row no-gutters align-items-stretch h-100">
            <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                    <div class="image">
                        <img src=<?php echo e(asset($productCategory->image_url)); ?> alt="Image" class="img-fluid" style="height: 200px">
                    </div>
                    <div class="text p-4">
                        <h2 class="h2 text-main"> <a href="<?php echo e(route('products', $productCategory->id)); ?>"><?php echo e($productCategory->name); ?></a></h2>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>
<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/frontend/page/productCategories.blade.php ENDPATH**/ ?>