<base href="/public">
<?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content" style="background-color: rgba(255,255,255);box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);margin-left:40px;margin-right:40px;">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Update </h4>
                </div>
                <div class="card-body">
                    <form id="riddle_update" method="post" action="<?php echo e(route('backend.users.update', $user->id)); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                        <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__(" Name ")); ?></label>
                                    <input type="text" name="name" class="form-control"
                                        value="<?php echo e(old('name',$user->name)); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="email"><?php echo e(__(" Email ")); ?></label>
                                    <input type="text" name="email" class="form-control"
                                        value="<?php echo e(old('email',$user->email)); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="username"><?php echo e(__(" Username ")); ?></label>
                                    <input type="text" name="username" class="form-control"
                                        value="<?php echo e(old('username',$user->username)); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'username'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="contact_no"><?php echo e(__(" Contact No ")); ?></label>
                                    <input type="text" name="contact_no" class="form-control"
                                        value="<?php echo e(old('contact_no',$user->contact_no)); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'contact_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="address"><?php echo e(__(" Address ")); ?></label>
                                    <input type="text" name="address" class="form-control"
                                        value="<?php echo e(old('address',$user->address)); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="password"><?php echo e(__("Password")); ?></label>
                                    <input type="password" name="password" class="form-control"
                                        value="<?php echo e(old('password')); ?>"required>
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                        <div class="card-footer ">
                            <button type="submit"
                                class="btn btn-primary float-right btn-round"><?php echo e(__('Update')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/profile/edit.blade.php ENDPATH**/ ?>