<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Projects List</h4>
                    <div class="pull-right">
                        <a href="<?php echo e(route('productCategory.create')); ?>">
                            <button class="btn btn-primary">Create</button>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-primary">
                                <th>ID</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($productCategory->id); ?></td>
                                    <td><img width="50px" src="<?php echo e(asset($productCategory->image_url )); ?>" alt=""></td>
                                    <td><?php echo e($productCategory->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('productCategory.edit',$productCategory->id)); ?>">
                                            <button class="btn btn-default">Edit</button>
                                        </a>
                                        <form method="post" action="<?php echo e(route('productCategory.destroy',$productCategory->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', [
    'namePage' => 'productCategory',
    'class' => 'sidebar-mini',
    'activePage' => 'productCategory',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/productCategory/index.blade.php ENDPATH**/ ?>