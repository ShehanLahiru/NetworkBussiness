<?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="site-section" style="background-image: url(images/main12.jpg); margin-top:1px;background-size: cover;
    background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-12 col-lg-12 mb-12">
            <div class="post-entry-main" style="background: rgba(0,0,0,.4)">
                <div class="text p-4">
                    <h2 class="h2 text-main-products" style="color: #fbc834">අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට 5කට විතර
                        දාන්න
                        පුලුවන්නේ අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට 5කට විතර
                        දාන්න
                        පුලුවන්නේ අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට 5කට විතර
                        දාන්න
                        පුලුවන්නේ අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට 5කට විතර
                        දාන්න
                        පුලුවන්නේ අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට
                    </h2><br>
                    <h2 class="h2 text-main-products" style="color: #fbc834">අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට 5කට විතර
                        දාන්න
                        පුලුවන්නේ අපිට 5කට විතර දාන්න පුලුවන්නේ අපිට
                    </h2><br>
                </div>
            </div>
        </div>
    </div>
    <div class="content"
        style="background: rgba(206, 157, 157, 0.4); margin-top:90px;margin-left:50px; margin-right:50px">
        <div class="row">
            <div class="col-md-4 col-lg-4 mb-4" style="">
                <button type="button" class=" btn btn-primary btn-lg" data-bs-toggle="modal"
                    data-bs-target="#exampleModal" style="display: block;
                margin-left: auto;
                margin-right: auto;
                margin-top: auto;
                margin-bottom: auto">
                    Pay Reload
                </button>
            </div>

            <div class="col-md-4 col-lg-4 mb-4" style="">
                <button type="button" class="btn btn-primary btn-lg" data-bs-toggle="modal"
                    data-bs-target="#exampleModal1" style="display: block;
                margin-left: auto;
                margin-right: auto;
                margin-top: auto;
                margin-bottom: auto">
                    Pay Bills
                </button>
            </div>

            <div class="col-md-4 col-lg-4 mb-4" style="">
                <button type="button" class="btn btn-primary btn-lg " data-bs-toggle="modal"
                    data-bs-target="#exampleModal2" style="display: block;
               margin-left: auto;
                margin-right: auto;
                margin-top: auto;
                margin-bottom: auto">
                    Apply Loan
                </button>
            </div>
        </div>
    </div>
</div>




<?php if(auth()->guard()->check()): ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Reloads List</h4>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary float-lg-right" data-bs-toggle="modal"
                        data-bs-target="#exampleModal">
                        Reload
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Add Reload</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form method="post" action="<?php echo e(route('reloads')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="row">
                                            <div class="col-md-7 pr-1">
                                                <div class="form-group">
                                                    <label for="number"><?php echo e(__("Number")); ?></label>
                                                    <input type="text" name="number" class="form-control"
                                                        value="<?php echo e(old('number')); ?>" required>
                                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-7 pr-1">
                                                <div class="form-group">
                                                    <label for="amount"><?php echo e(__("Amount")); ?></label>
                                                    <input type="text" name="amount" class="form-control"
                                                        value="<?php echo e(old('amount')); ?>" required>
                                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Pay</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>ID</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($reload->id); ?></td>
                                <td><?php echo e($reload->amount); ?></td>
                                <td><?php echo e($reload->status); ?></td>
                                <td><?php echo e($reload->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Billings List</h4>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary float-lg-right" data-bs-toggle="modal"
                        data-bs-target="#exampleModal1">
                        Pay Bills
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Pay Bills</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form method="post" action="<?php echo e(route('payBills')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="row">
                                            <div class="col-md-7 pr-1">
                                                <div class="form-group">
                                                    <label for="name"><?php echo e(__("Name")); ?></label>
                                                    <input type="text" name="name" class="form-control"
                                                        value="<?php echo e(old('name')); ?>" required>
                                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-7 pr-1">
                                                <div class="form-group">
                                                    <label for="acc_no"><?php echo e(__("Account No")); ?></label>
                                                    <input type="text" name="acc_no" class="form-control"
                                                        value="<?php echo e(old('acc_no')); ?>" required>
                                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'acc_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-7 pr-1">
                                                <div class="form-group">
                                                    <label for="company"><?php echo e(__("Company")); ?></label>
                                                    <select name="company" class="form-control"  style="border:1px solid #E3E3E3" required>
                                                        <option value="Insurance">Insurance</option>
                                                        <option value="DialogTv">DialogTv</option>
                                                        <option value="Sri Lanka Telecom">Sri Lanka Telecom</option>
                                                        <option value="Dialog">Dialog</option>
                                                        <option value="Mobitel">Mobitel</option>
                                                        <option value="Etisalat">Etisalat</option>
                                                        <option value="Hutch">Hutch</option>
                                                    </select>
                                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'company'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-7 pr-1">
                                                <div class="form-group">
                                                    <label for="amount"><?php echo e(__("Amount")); ?></label>
                                                    <input type="text" name="amount" class="form-control"
                                                        value="<?php echo e(old('amount')); ?>" required>
                                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Pay</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>ID</th>
                            <th>Company</th>
                            <th>Account No</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $payBills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payBill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payBill->id); ?></td>
                                <td><?php echo e($payBill->company); ?></td>
                                <td><?php echo e($payBill->acc_no); ?></td>
                                <td><?php echo e($payBill->amount); ?></td>
                                <td><?php echo e($payBill->status); ?></td>
                                <td><?php echo e($payBill->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Loans List</h4>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary float-lg-right" data-bs-toggle="modal"
                        data-bs-target="#exampleModal2">
                        Apply Loan
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Apply Loans</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form method="post" action="<?php echo e(route('loans')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="row">
                                            <div class="col-md-7 pr-1">
                                                <div class="form-group">
                                                    <label for="amount"><?php echo e(__("Amount")); ?></label>
                                                    <input type="text" name="amount" class="form-control"
                                                        value="<?php echo e(old('amount')); ?>" required>
                                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Apply</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>ID</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loan->id); ?></td>
                                <td><?php echo e($loan->amount); ?></td>
                                <td><?php echo e($loan->status); ?></td>
                                <td><?php echo e($loan->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"
    integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"
    integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous">
</script>

<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/frontend/page/billing.blade.php ENDPATH**/ ?>