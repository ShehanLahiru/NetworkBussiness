<?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="site-section">
    <div class="container">
        <div class="row no-gutters align-items-stretch h-100">
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                   <iframe src="https://www.youtube.com/embed/VA23BcWW1FY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="text p-4">
                        <h2 class="h2 text-main">Title</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                   <iframe src="https://www.youtube.com/embed/VA23BcWW1FY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="text p-4">
                        <h2 class="h2 text-main">Title</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                   <iframe src="https://www.youtube.com/embed/VA23BcWW1FY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="text p-4">
                        <h2 class="h2 text-main">Title</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                   <iframe src="https://www.youtube.com/embed/VA23BcWW1FY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="text p-4">
                        <h2 class="h2 text-main">Title</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                   <iframe src="https://www.youtube.com/embed/VA23BcWW1FY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="text p-4">
                        <h2 class="h2 text-main">Title</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                   <iframe src="https://www.youtube.com/embed/VA23BcWW1FY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="text p-4">
                        <h2 class="h2 text-main">Title</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/frontend/page/videoes.blade.php ENDPATH**/ ?>