<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8"/>

    
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('assets/favicon/apple-icon-57x57.png')); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('assets/favicon/apple-icon-60x60.png')); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('assets/favicon/apple-icon-72x72.png')); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('assets/favicon/apple-icon-76x76.png')); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('assets/favicon/apple-icon-114x114.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('assets/favicon/apple-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('assets/favicon/apple-icon-144x144.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('assets/favicon/apple-icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/favicon/apple-icon-180x180.png')); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset('assets/favicon/android-icon-192x192.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('assets/favicon/favicon-96x96.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/favicon/favicon-16x16.png')); ?>">

    <link href =
        "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css"
            rel = "stylesheet">
    <link rel="manifest" href="<?php echo e(asset('assets/favicon/manifest.json')); ?>">

    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <!-- Extra details for Live View on GitHub Pages -->
    <!-- Canonical SEO -->
    <link rel="canonical" href=""/>


    <!--  Social tags      -->
    <meta name="keywords" content="">
    <meta name="description" content="Remote Promotions">
    <meta itemprop="image" content="<?php echo e(asset('images/logo.jpg')); ?>">


    <!-- Twitter Card data -->
    <meta name="twitter:card" content="product">
    <meta name="twitter:site" content=">
    <meta name="twitter:title" content="">

    <meta name="twitter:description" content="">
    <meta name="twitter:creator" content="">
    <meta name="twitter:image" content="<?php echo e(asset('images/logo.jpg')); ?>">


    <!-- Open Graph data -->
    <meta property="fb:app_id" content="">
    <meta property="og:title" content=""/>
    <meta property="og:type" content="article"/>
    <meta property="og:url" content="http://demos.creative-tim.com/now-ui-dashboard-pro/examples/dashboard.html"/>
    <meta property="og:image" content="<?php echo e(asset('images/logo.jpg')); ?>"/>
    <meta property="og:description"
          content=" Remote Promotions"/>
    <meta property="og:site_name" content="Remote Promotions"/>
    <title>
        Remote Promotions
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
          name='viewport'/>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"
          integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- CSS Files -->
    <link href="<?php echo e(asset('assets')); ?>/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets')); ?>/css/now-ui-dashboard.css?v=1.3.0" rel="stylesheet"/>
    <link href="<?php echo e(asset('select2/select2.min.css')); ?>" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.min.css')); ?>">
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="<?php echo e(asset('assets')); ?>/demo/demo.css" rel="stylesheet"/>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets')); ?>/js/core/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/core/popper.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/core/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('select2/select2.min.js')); ?>"></script>


</head>

<body class="<?php echo e($class ?? ''); ?>">

<div class="wrapper">
    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('backend.layouts.page_template.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <?php echo $__env->make('backend.layouts.page_template.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div>


<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets')); ?>/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!-- Chart JS -->
<script src="<?php echo e(asset('assets')); ?>/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('assets')); ?>/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="<?php echo e(asset('assets')); ?>/js/now-ui-dashboard.min.js?v=1.3.0" type="text/javascript"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo e(asset('assets')); ?>/demo/demo.js"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet"/>
<?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>