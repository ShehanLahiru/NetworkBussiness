<base href="/public">
<?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="panel-header panel-header-sm">
    <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="site-section" style="background-image: url(images/main1.jpg);background-size: cover;
background-repeat: no-repeat;">
    <div class="container"style="margin-top:0px">
        <div class="row">
            <div class="col-md-12 col-lg-12 mb-12">
                <div class="card"  style="box-shadow: 3px 6px 15px 0 rgba(0,0,0,.4);background: rgba(0,0,0,.6);border-radius: 40px;border:2px solid #fbc834">
                    <div class="card-header">
                        <h4 class="card-title" style="color: white"> Register Here</h4>
                    </div>
                    <div class="card-body">
                        <form id="riddle_create" method="post" action="<?php echo e(route('register.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-7 pr-1">
                                            <div class="form-group">
                                                <label for="name"style="color: white"><?php echo e(__("Name")); ?></label>
                                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" style="color: black;font-weight: 800;background: rgba(255,255,255,.4)">
                                                <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7 pr-1">
                                            <div class="form-group">
                                                <label for="username"style="color: white"><?php echo e(__("Username")); ?></label>
                                                <input type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>" style="color: black;font-weight: 800;background: rgba(255,255,255,.4)">
                                                <?php echo $__env->make('backend.alerts.feedback', ['field' => 'username'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>

                                <div class="row">
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="email"style="color: white"><?php echo e(__("Email")); ?></label>
                                        <input type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>" style="color: black;font-weight: 800;background: rgba(255,255,255,.4)">
                                        <?php echo $__env->make('backend.alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="password"style="color: white"><?php echo e(__("Password")); ?></label>
                                        <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" style="color: black;font-weight: 800;background: rgba(255,255,255,.4)">
                                        <?php echo $__env->make('backend.alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label for="contact_no"style="color: white"><?php echo e(__("Contact No")); ?></label>
                                                <input type="text" name="contact_no" class="form-control" value="<?php echo e(old('contact_no')); ?>" style="color: black;font-weight: 800;background: rgba(255,255,255,.4)">
                                                <?php echo $__env->make('backend.alerts.feedback', ['field' => 'contact_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label for="address"style="color: white"><?php echo e(__("Adress")); ?></label>
                                                <input type="text" name="address" class="form-control" value="<?php echo e(old('address')); ?>" style="color: black;font-weight: 800;background: rgba(255,255,255,.4)">
                                                <?php echo $__env->make('backend.alerts.feedback', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7 pr-1">
                                            <div class="form-group">
                                                <label for="parent_id"style="color: white"><?php echo e(__("Parent ID")); ?></label>
                                                <input type="text" name="parent_id" class="form-control" value="<?php echo e(old('parent_id')); ?>" style="color: black;font-weight: 800;background: rgba(255,255,255,.4)">
                                                <?php echo $__env->make('backend.alerts.feedback', ['field' => 'parent_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer ">
                                <button type="submit"
                                    class="btn btn-primary float-right btn-round"><?php echo e(__('Register')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/frontend/page/register.blade.php ENDPATH**/ ?>