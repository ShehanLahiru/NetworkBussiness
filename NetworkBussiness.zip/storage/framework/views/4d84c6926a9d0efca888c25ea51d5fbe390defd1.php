<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="pull-right">
                    <a href="<?php echo e(route('backend.users.index')); ?>">
                        <button class="btn btn-dark" style="margin-right: 15px;">Back</button>
                    </a>
                </div>
                <div class="card-header">
                    <h4 class="card-title"> Update Users</h4>
                </div>
                <div class="card-body">
                    <form id="riddle_update" method="post" action="<?php echo e(route('backend.projects.update', $user->id)); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <?php echo $__env->make('backend.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__(" Name ")); ?></label>
                                    <input type="text" name="title" class="form-control"
                                        value="<?php echo e(old('name',$user->name)); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="email"><?php echo e(__(" Email ")); ?></label>
                                    <input type="text" name="email" class="form-control"
                                        value="<?php echo e(old('email',$user->email)); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7 pr-1">
                                <div class="form-group">
                                    <label for="balance"><?php echo e(__(" Balance ")); ?></label>
                                    <input type="text" name="balance" class="form-control"
                                        value="<?php echo e(old('email',$user->balance)); ?>">
                                    <?php echo $__env->make('backend.alerts.feedback', ['field' => 'balance'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer ">
                            <button type="submit"
                                class="btn btn-primary float-right btn-round"><?php echo e(__('Update')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', [
'namePage' => 'users',
'class' => 'sidebar-mini',
'activePage' => 'users',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/users/edit.blade.php ENDPATH**/ ?>