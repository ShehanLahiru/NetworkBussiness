<div class="sidebar" data-color="orange">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
  -->
    <div class="logo">
        <a href="<?php echo e(route('backend.dashboard')); ?>" class="simple-text logo-normal">
            <?php echo e(__('Remote Promotions')); ?>

        </a>
    </div>
    <div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
            <li class="<?php if($activePage == 'home'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('backend.dashboard')); ?>">
                    <i class="now-ui-icons design_app"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'users'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('backend.users.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('USERS')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'accounts'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('accounts')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Account Summery')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'marketings'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('account.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Marketings')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'withdraws'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('withdraw.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('withdraws')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'products'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('product.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Products')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'productCategory'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('productCategory.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Product Categories')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'payBills'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('payBill.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Billing')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'reloads'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('reload.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Reload')); ?></p>
                </a>
            </li>
            <li class="<?php if($activePage == 'loans'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('loan.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Loan')); ?></p>
                </a>
            </li>

            <li class="<?php if($activePage == 'customers'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('backend.customers.index')); ?>">
                    <i class="fas fa-user"></i>
                    <p><?php echo e(__('Customers')); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>