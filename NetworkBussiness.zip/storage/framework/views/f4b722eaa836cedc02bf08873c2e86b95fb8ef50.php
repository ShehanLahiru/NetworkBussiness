<footer class="footer">
  <div class=" container-fluid ">
    <div class="copyright" id="copyright">
      &copy;
      <script>
        document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
      </script>, <?php echo e(__(" Designed by")); ?>

      <a href="" target="_blank">Bee Technology/a>
    </div>
  </div>
</footer>
<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>