<base href="/public">
<?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="site-section">
    <div class="container">
        <div class="row no-gutters align-items-stretch h-100">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 mb-6">
                <div class="post-entry-products">
                    <div class="image">
                        <img src=<?php echo e(asset($product->image_url)); ?> alt="Image" class="img-fluid" style="height: 200px">
                    </div>
                    <div class="text p-4">
                        <h2 class="h2 text-main"> <a target="_blank" href="<?php echo e($product->link); ?>"><?php echo e($product->name); ?></a></h2>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/frontend/page/product.blade.php ENDPATH**/ ?>