<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Users List</h4>
                    <form id="item" method="post" action="<?php echo e(route('backend.searchByID','User')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-3">
                            <div class="form-group">
                                <label for="id"><?php echo e(__("Search by ID")); ?></label>
                                <input type="text" class="form-control" name="id">
                                </div>
                            </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Search')); ?></button>
                        </div>
                    </div>
                </form>
                <form id="item" method="post" action="<?php echo e(route('backend.searchByName','User')); ?>"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-3">
                        <div class="form-group">
                            <label for="name"><?php echo e(__("Search by Name")); ?></label>
                            <input type="text" class="form-control" name="name">
                            </div>
                        </div>
                    <div class="col-6">
                        <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Search')); ?></button>
                    </div>
                </div>
            </form>
                <div class="pull-right">
                    <a href="<?php echo e(route('backend.users.create')); ?>">
                        <button class="btn btn-primary">Create</button>
                    </a>
                </div>
            </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-primary">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Balance</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->balance); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('view',$user->id)); ?>">
                                            <button class="btn btn-default">View</button>
                                        </a>
                                        <?php if($user->status == "active"): ?>
                                        <form method="post" action="<?php echo e(route('backend.users.destroy',$user->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger" type="submit">Deactive</button>
                                        </form>
                                        <?php else: ?>
                                        <form method="post" action="<?php echo e(route('backend.users.destroy',$user->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger" type="submit">Active</button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', [
    'namePage' => 'users',
    'class' => 'sidebar-mini',
    'activePage' => 'users',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/users/index.blade.php ENDPATH**/ ?>