<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> To Add List</h4>
                    <form id="item" method="post" action="<?php echo e(route('backend.searchByID','Marketing')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-3">
                            <div class="form-group">
                                <label for="id"><?php echo e(__("Search by ID")); ?></label>
                                <input type="text" class="form-control" name="id">
                                </div>
                            </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Search')); ?></button>
                        </div>
                    </div>
                </form>
                    <div class="pull-right">
                        <a href="<?php echo e(route('account.create')); ?>">
                            <button class="btn btn-primary">Add</button>
                        </a>
                    </div>
                    <form id="item" method="post" action="<?php echo e(route('backend.searchByDate','Marketing')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-3">
                            <div class="form-group">
                                <label for="from"><?php echo e(__(" From")); ?></label>
                                <input type="text" class="form-control" name="from" data-provide="datepicker">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-th"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="to"><?php echo e(__("To")); ?></label>
                                <input type="text" class="form-control" name="to" data-provide="datepicker">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-th"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-6">
                            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Search')); ?></button>
                        </div>
                    </div>
                </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-primary">
                                <th>ID</th>
                                <th>User ID</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Action</th>

                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $marketings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($marketing->id); ?></td>
                                    <td><?php echo e($marketing->user_id); ?></td>
                                    <td><img width="50px" src="<?php echo e(asset($marketing->image_url )); ?>" alt=""></td>
                                    <td><?php echo e($marketing->name); ?></td>
                                    <td><?php echo e($marketing->amount); ?></td>
                                    <td><?php echo e($marketing->status); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('account.edit',$marketing->id)); ?>">
                                            <button class="btn btn-default">Voucher</button>
                                        </a>
                                        <?php if( $marketing->status=='pending' ): ?>
                                            <form method="post" action="<?php echo e(route('account.destroy',$marketing->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger" type="submit">Delete</button>
                                            </form>
                                            <form method="post" action="<?php echo e(route('account.changeStatus',$marketing->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('post'); ?>
                                                <button class="btn btn-primary" type="submit">Confirm</button>
                                            </form>
                                            <?php endif; ?>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo e($marketings->links()); ?>

</div>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript"
    src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
<script>
    $(".form-control").attr("autocomplete", "off");
    $(document).ready(function() {
        $('.datepicker').datepicker();
    });
</script>
<link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', [
    'namePage' => 'marketings',
    'class' => 'sidebar-mini',
    'activePage' => 'marketings',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/marketings/index.blade.php ENDPATH**/ ?>