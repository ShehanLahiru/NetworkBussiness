<?php $__env->startSection('content'); ?>
    <div class="panel-header panel-header-sm">
    </div>
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="pull-right">
                        <a href="<?php echo e(route('backend.customers.index')); ?>">
                            <button class="btn btn-dark" style="margin-right: 15px;">Back</button>
                        </a>
                    </div>
                    <div class="card-header">
                        <h4 class="card-title"> Mesaage</h4>
                    </div>
                    <div class="card-body">
                            <div class="row">
                                <div class="col-md-7 pr-1">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(__(" Name ")); ?></label>
                                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name',$customer->name)); ?>">
                                        <?php echo $__env->make('backend.alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 pr-1">
                                    <div class="form-group">
                                        <label for="email"><?php echo e(__(" Email ")); ?></label>
                                        <input type="text" name="email" class="form-control" value="<?php echo e(old('email',$customer->email)); ?>">
                                        <?php echo $__env->make('backend.alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 pr-1">
                                    <div class="form-group">
                                        <label for="contact_no"><?php echo e(__(" Contact No ")); ?></label>
                                        <input type="text" name="contact_no" class="form-control" value="<?php echo e(old('contact_no',$customer->contact_no)); ?>">
                                        <?php echo $__env->make('backend.alerts.feedback', ['field' => 'contact_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 pr-1">
                                    <div class="form-group">
                                        <label for="message"><?php echo e(__(" Message")); ?></label>
                                        <textarea type="text" rows="20" name="message" class="form-control" style="border:1px solid #E3E3E3"><?php echo e(old('message',$customer->message)); ?></textarea>
                                        <?php echo $__env->make('backend.alerts.feedback', ['field' => 'message'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                           </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', [
    'namePage' => 'customers',
    'class' => 'sidebar-mini',
    'activePage' => 'customers',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NetworkBussiness\resources\views/backend/pages/customers/show.blade.php ENDPATH**/ ?>